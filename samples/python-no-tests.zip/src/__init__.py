"""Calculator package module."""
